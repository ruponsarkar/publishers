
<?php
include_once('../database/dbcon.php');
if(isset($_POST['submit'])){
    $id = $_POST['id'];
    $name=$_POST['name'];
    $aname = $_POST['aname'];
    $designation = $_POST['designation'];
    $doi = $_POST['doi'];
    $page = $_POST['page'];


    $sql = "UPDATE `article` SET `name`='$name',`aname`='$aname',`designation`='$designation',`doi`='$doi', `page`='$page' WHERE `id` = '$id'";

    $run = mysqli_query($con,$sql);

    if($run == true){
        ?>
        <script>
            alert('Updated');
            window.location.href='update-article.php?id=<?php echo $id;  ?>';
        </script>
        <?php
    }
    else{
        echo "error";

    }
}

// for image 

if(isset($_POST['img-file'])){
    $id = $_POST['id'];
    $file = $_FILES["file"]["name"];
    $tempname = $_FILES['file']['tmp_name'];

    move_uploaded_file($tempname,"../assets/finalsubmit/$file");

    $sql = "UPDATE `article` SET `file`= '$file' WHERE `id`= '$id'";

    $run = mysqli_query($con,$sql);

    if($run == true){
        ?>
        <script>
            alert('Updated');
            window.location.href='update-article.php?id=<?php echo $id;  ?>';
        </script>
        <?php
    }
    else{
        echo "error";
    }
}

?>









<!-- home-article-data  -->



<?php
include_once('../database/dbcon.php');
if(isset($_POST['home-article-submit'])){
    $id = $_POST['id'];
    $name=$_POST['name'];
    $aname = $_POST['aname'];
    $designation = $_POST['designation'];
    $doi = $_POST['doi'];
    $page = $_POST['page'];


    $sql = "UPDATE `home-article` SET `name`='$name',`aname`='$aname',`designation`='$designation',`doi`='$doi', `page`='$page' WHERE `id` = '$id'";

    $run = mysqli_query($con,$sql);

    if($run == true){
        ?>
        <script>
            alert('Updated');
            window.location.href='home-article.php';
        </script>
        <?php
    }
    else{
        echo "error";

    }
}

// for image 

if(isset($_POST['home-img-file'])){
    $id = $_POST['id'];
    $file = $_FILES["file"]["name"];
    $tempname = $_FILES['file']['tmp_name'];

    move_uploaded_file($tempname,"../assets/finalsubmit/$file");

    $sql = "UPDATE `home-article` SET `file`= '$file' WHERE `id`= '$id'";

    $run = mysqli_query($con,$sql);

    if($run == true){
        ?>
        <script>
            alert('Updated');
            window.location.href='home-article.php';
        </script>
        <?php
    }
    else{
        echo "error";
    }
}

?>
















