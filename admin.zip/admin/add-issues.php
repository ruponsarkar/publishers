
<?php

session_start();
if(!isset($_SESSION['uid']))
{
	header('location:login/index.php');
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Journals</title>
    <link rel="stylesheet" href="admin.css">

    <style>
    .list-v{
    width: 200px;
    height: 30px;
    border: 1px solid;
    margin: 10px;
    display: flex;
    align-items: center;
    background-color: burlywood;
    color: black;
    padding: 5px;
    border-radius: 3px;
    
    }

    .list-v:hover{
        background-color: red;
    }

    .volume-list{
        display: flex;
    justify-content: center;
    flex-direction: column;
    align-content: center;
    flex-wrap: wrap;
    }
    </style>


</head>
<body>
<?php
$id = $_GET['id'];
?>

<div class="container-form">
    <h1>Add ISSUES</h1>

<form action="add-data.php?id=<?php echo $id ?>" method="post" enctype="multipart/form-data">

<div class="one">
<label for="language">ISSUES</label>
<select name="name" id="">
<option value="Issue 1">Issue 1</option>
<option value="Issue 2">Issue 2</option>
<option value="Issue 3">Issue 3</option>
<option value="Issue 4">Issue 4</option>
<option value="Issue 5">Issue 5</option>
<option value="Issue 6">Issue 6</option>
<option value="Issue 7">Issue 7</option>
<option value="Issue 8">Issue 8</option>
<option value="Issue 9">Issue 9</option>
<option value="Issue 10">Issue 10</option>
<option value="Issue 11">Issue 11</option>
<option value="Issue 12">Issue 12</option>


</select>
</div>

<div class="one">

<input type="submit" name="submit-issues" value="Save" id="">
</div>
</form>

</div>



<div class="volume-list">

<?php    

include_once('../database/dbcon.php');
$id = $_GET['id'];

$sql = "SELECT * FROM issues WHERE v_id = $id";
$qry = mysqli_query($con,$sql);

while($row = mysqli_fetch_assoc($qry)){

?>

  <a href="add-article.php?id=<?php echo $row['id']; ?>&v_id=<?php echo $id ?>">
  <div class="list-v">
   <?php echo $row['name'] ; ?> <br>
</div>
  </a>

<?php
}



?>






</div>















</body>
</html>