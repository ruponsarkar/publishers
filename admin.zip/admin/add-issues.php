
<?php

session_start();
if(!isset($_SESSION['uid']))
{
	header('location:login/index.php');
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Journals</title>
    <link rel="stylesheet" href="admin.css">
</head>
<body>
<?php
$id = $_GET['id'];
?>

<div class="container-form">
    <h1>Add ISSUES</h1>

<form action="add-data.php?id=<?php echo $id ?>" method="post" enctype="multipart/form-data">
<div class="one">
<label for="name">ISSUES Name</label>
<input type="text" name="name" id="">
</div>

<div class="one">

<input type="submit" name="submit-issues" value="Save" id="">
</div>
</form>

</div>



<div class="volume-list">

<?php    

include_once('../database/dbcon.php');
$id = $_GET['id'];

$sql = "SELECT * FROM issues WHERE v_id = $id";
$qry = mysqli_query($con,$sql);

while($row = mysqli_fetch_assoc($qry)){

?>

  <a href="add-article.php?id=<?php echo $row['id']; ?>&v_id=<?php echo $id ?>"> <?php echo $row['name'] ; ?> <br> </a>

<?php
}



?>






</div>















</body>
</html>