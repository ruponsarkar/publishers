

<?php
include_once('../database/dbcon.php');
if(isset($_POST['submit'])){
    $id = $_POST['id'];
    $name=$_POST['name'];
    $details = $_POST['details'];
    $university = $_POST['university'];


    $sql = "UPDATE `slide_editors` SET `name`='$name',`university`='$university',`details`='$details' WHERE `id` = '$id'";

    $run = mysqli_query($con,$sql);

    if($run == true){
        ?>
        <script>
            alert('Updated');
            window.location.href='all-slider-editors.php';
        </script>
        <?php
    }
    else{
        echo "error";

    }

}


// for image 


if(isset($_POST['img-change'])){
    $id = $_POST['id'];


    $photo = $_FILES["photo"]["name"];
    $tempname = $_FILES['photo']['tmp_name'];

    move_uploaded_file($tempname,"../assets/all-editors/slider/$photo");

    $sql = "UPDATE `slide_editors` SET `image`= '$photo' WHERE `id`= '$id'";

    $run = mysqli_query($con,$sql);

    if($run == true){
        ?>
        <script>
            alert('Updated');
            window.location.href='all-slider-editors.php';
        </script>
        <?php
    }
    else{
        echo "error";

    }

    

   

}





?>

