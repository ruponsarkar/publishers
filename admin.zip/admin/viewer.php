<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>



<?php
if($_GET['type'] == "re"){
    $id = $_GET['id'];


include_once("../database/dbcon.php");

$sql = "SELECT * FROM reviewers WHERE r_id = $id";

$qry = mysqli_query($con,$sql);

$result = mysqli_fetch_assoc($qry);


echo $result['name'];
echo "| File: ";
echo $result['cv'];

?>
<br/>
<iframe src='../assets/reviewers/cv/<?php echo $result['cv'];  ?>' width='1366px' height='623px' frameborder='0'></iframe>


<?php
}

elseif($_GET['type']== 'edi'){
    $id = $_GET['id'];


    include_once("../database/dbcon.php");
    
    $sql = "SELECT * FROM editors WHERE e_id = $id";
    
    $qry = mysqli_query($con,$sql);
    
    $result = mysqli_fetch_assoc($qry);
    
    
    echo $result['name'];
    echo "| File: ";
    echo $result['cv'];
    
    ?>
    <br/>
    <iframe src='../assets/editors/cv/<?php echo $result['cv'];  ?>' width='1366px' height='623px' frameborder='0'></iframe>
    
    
    <?php
}

elseif($_GET['type']== 'manu'){
    $id = $_GET['id'];


    include_once("../database/dbcon.php");
    
    $sql = "SELECT * FROM manuscript WHERE m_id = $id";
    
    $qry = mysqli_query($con,$sql);
    
    $result = mysqli_fetch_assoc($qry);
    
    
    echo $result['author'];
    echo "| File: ";
    echo $result['file'];
    
    ?>
    <br/>
    <iframe src='../assets/manuscript/<?php echo $result['file'];  ?>' width='1366px' height='623px' frameborder='0'></iframe>
    
    
    <?php


}

else {
    echo "error";
}



?>







    
</body>
</html>