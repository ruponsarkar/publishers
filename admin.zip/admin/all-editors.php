
<?php

session_start();
if(!isset($_SESSION['uid']))
{
	header('location:login/index.php');
}


?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Editors</title>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>
<body>

<h2>Edit editors</h2>

<table>
  <tr>
    <th>Name</th>
    <th>University</th>
    <th>Details</th>
    <th>Type</th>
    <th>Photo</th>
    <th>Edit</th>
  </tr>

  <?php
    include_once('../database/dbcon.php');
    $sql = "SELECT * FROM editors_data ";
    $qry = mysqli_query($con,$sql);

    while($row = mysqli_fetch_assoc($qry))
    {

    ?>
  <tr>
    <td><?php echo $row['name'];  ?></td>
    <td><?php echo $row['university'];  ?></td>
    <td><?php echo $row['details'] ?></td>
    <td><?php echo $row['type'] ?></td>
    <td><a href="../assets/all-editors/<?php echo $row['image'];  ?>"><?php echo $row['image'] ?></a></td>
    <td><a href="update-editors.php?id=<?php echo $row['id'];  ?>">Edit</a></td>
  </tr>
  <?php }  ?>
</table>

</body>
</html>

