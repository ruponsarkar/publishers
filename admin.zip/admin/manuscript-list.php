
<?php

session_start();
if(!isset($_SESSION['uid']))
{
	header('location:login/index.php');
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php  include_once('../database/dbcon.php'); 

$link = $_GET['id'];


$sql = "SELECT m_id, author, file FROM manuscript WHERE m_id= $link";
$result = $con->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo "M_id: " . $row["m_id"]. " ". "Author " . $row["author"] . " File: " . $row["file"] . "<br>";


    ?>



<embed src="../assets/manuscript/<?php echo $row["file"]; ?>" type="application/pdf" width="100%" height="600px" />


<?php




  }
} else {
  echo "0 results";
}
$con->close();

?>
    
</body>
</html>