
<?php

session_start();
if(!isset($_SESSION['uid']))
{
	header('location:login/index.php');
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Slider editors</title>
    <link rel="stylesheet" href="admin.css">
</head>
<body>

<?php  
include_once('../database/dbcon.php');


$sql = "SELECT * FROM journals";
$qry = mysqli_query($con,$sql);

?>

<div class="container-form">

<h1>Slider Editors</h1>
<form action="add-data.php" method="post" enctype="multipart/form-data">
<div class="one">
<label for="jname">Editors Name</label>
<input type="text" name="name" id="">
</div>

<div class="one">
<label for="abbr">University Name</label>
<input type="text" name="university" id="">
</div>

<div class="one">
<label for="issn">Details (*Optional)</label>
<input type="text" name="details" id="">
</div>




<div class="one">
<label for="photo">Photo</label>
<input type="file" name="photo" id="">
</div>

<div class="one">

<input type="submit" name="submit-slider-editors" value="Save" id="">
</div>
</form>


</div>















</body>
</html>