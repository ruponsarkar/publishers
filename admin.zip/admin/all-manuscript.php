
<?php

session_start();
if(!isset($_SESSION['uid']))
{
	header('location:login/index.php');
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Manuscript</title>

    


    <style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid black;
  text-align: left;
  padding: 8px;
}

tr:nth-child(1) {
  background-color: #dddddd;
}
</style>



</head>
<body>
    


<div class="container">
        <div class="heading">
           <center><h1> All Manuscript </h1> </center>
        </div>
    </div>

    <table>
  <tr>
    <th>Id</th>
    <th>File</th>
     <th>Mode</th>
    <th>Author</th>
    <th>email</th>
    <th>Mobile</th>
    <th>Journal</th>
    <th>Manuscript</th>
    <th>Type</th>
    <th>Affiliation</th>
    <th>Date</th>
  </tr>



<?php  include_once('../database/dbcon.php'); 




$sql = "SELECT * FROM manuscript";
$result = $con->query($sql);





if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    


    ?>
 <tr>
   <td><?php echo $row["m_id"];  ?></td>
    <td><a href="viewer.php?id=<?php echo $row["m_id"];  ?>&type=manu "> <?php echo $row["file"];  ?>   </a></td>
      
      <td><?php echo $row["mode"];  ?></td>
      <td><?php echo $row["author"];  ?></td>
      <td><?php echo $row["email"];  ?></td>
      <td><?php echo $row["mobile"];  ?></td>
      <td><?php echo $row["journal"];  ?></td>
      <td><?php echo $row["manuscript"];  ?></td>
      <td><?php echo $row["type"];  ?></td>
      <td><?php echo $row["affiliation"];  ?></td>
      <td><?php echo $row["date"];  ?></td>
    </tr>



<!-- 
<iframe src = "../assets/manuscript/<?php $row["file"]  ?>" width='700'></iframe> -->


<?php




  }
} else {
  echo "0 results";
}
$con->close();

?>
    
</body>
</html>