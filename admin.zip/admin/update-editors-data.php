

<?php
include_once('../database/dbcon.php');
if(isset($_POST['submit'])){
    $id = $_POST['id'];
    $name=$_POST['name'];
    $details = $_POST['details'];
    $university = $_POST['university'];
    $details = $_POST['details'];
    $type = $_POST['type'];


    $sql = "UPDATE `editors_data` SET `name`=$name,`university`=$university,`details`=$details,`type`=$type, WHERE `id` = $id";

    $qry = mysqli_query($con, $sql);




}




?>

