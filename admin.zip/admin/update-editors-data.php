

<?php
include_once('../database/dbcon.php');
if(isset($_POST['submit'])){
    $id = $_POST['id'];
    $name=$_POST['name'];
    $details = $_POST['details'];
    $university = $_POST['university'];
    $type = $_POST['type'];


    $sql = "UPDATE `editors_data` SET `name`='$name',`university`='$university',`details`='$details',`type`='$type' WHERE `id` = '$id'";

    $run = mysqli_query($con,$sql);

    if($run == true){
        ?>
        <script>
            alert('Updated');
            window.location.href='all-editors.php';
        </script>
        <?php
    }
    else{
        echo "error";

    }

}


// for image 


if(isset($_POST['img-change'])){
    $id = $_POST['id'];


    $photo = $_FILES["photo"]["name"];
    $tempname = $_FILES['photo']['tmp_name'];

    move_uploaded_file($tempname,"../assets/all-editors/$photo");

    $sql = "UPDATE `editors_data` SET `image`= '$photo' WHERE `id`= '$id'";

    $run = mysqli_query($con,$sql);

    if($run == true){
        ?>
        <script>
            alert('Updated');
            window.location.href='all-editors.php';
        </script>
        <?php
    }
    else{
        echo "error";

    }

    

   

}





?>

