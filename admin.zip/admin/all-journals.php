
<?php

session_start();
if(!isset($_SESSION['uid']))
{
	header('location:login/index.php');
}


?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Journals</title>
    <?php include_once('partial/dash-link.html');  ?>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(1) {
  background-color: #dddddd;
}
</style>
</head>
<body>

<?php include_once('partial/dash-sidebar.html');  ?>

<center><h2>Edit Journals</h2></center>

<table>
  <tr>
    <th>Name</th>
    <th>Abbr. title</th>
    <th>ISSN</th>
    <th>Frequency</th>
    <th>Language</th>
    <th>Chief Editor</th>

    <th>Publisher</th>
    <th>Country of origin</th>
    <th>Aim and Scope</th>
    <th>Image</th>
    <th>Update</th>

  </tr>

  <?php
    include_once('../database/dbcon.php');
    $sql = "SELECT * FROM journals ";
    $qry = mysqli_query($con,$sql);

    while($row = mysqli_fetch_assoc($qry))
    {

    ?>
  <tr>
    <td><?php echo $row['j_name'];  ?></td>
    <td><?php echo $row['abbr_title'];  ?></td>
    <td><?php echo $row['issn'] ?></td>
    <td><?php echo $row['frequency'] ?></td>
    <td><?php echo $row['language'] ?></td>
    <td><?php echo $row['chief_editor'] ?></td>
    <td><?php echo $row['publisher'] ?></td>
    <td><?php echo $row['country_of_origin'] ?></td>
    <td><?php echo $row['aim_and_scope'] ?></td>
    
    

    <td><a href="../assets/journals/<?php echo $row['photo'];  ?>"><?php echo $row['photo'] ?></a></td>
    <td><a href="update-journals.php?id=<?php echo $row['j_id'];  ?>">Update</a></td>
  </tr>
  <?php }  ?>
</table>
<?php include_once('partial/dash-bottom.html'); ?>
</body>
</html>

