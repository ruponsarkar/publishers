
<?php

session_start();
if(!isset($_SESSION['uid']))
{
	header('location:login/index.php');
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Journals</title>
    <link rel="stylesheet" href="admin.css">

    <style>
    .list-v{
    width: 90%;
    height: 30px;
    border: 1px solid;
    margin: 10px;
    display: flex;
    align-items: center;
    background-color: burlywood;
    color: black;
    padding: 5px;
    border-radius: 3px;
    
    }

    .list-link{
        width: auto;
    height: 30px;
    border: 1px solid;
    margin: 10px;
    display: flex;
    align-items: center;
    background-color: red;
    color: black;
    padding: 5px;
    border-radius: 3px;
    color: white;
    }

    .list-link:hover{
        background-color: blue;
       
    }

    .volume-list{
        display: flex;
    justify-content: center;
    flex-direction: column;
    align-content: center;
    flex-wrap: wrap;
    }

    .whole-list{
        width: 100%;
        margin: 0px;
        display: flex;
    }


    </style>


</head>
<body>


<div class="container-form">
    <h1>Add Home Article</h1>

<form action="add-data.php" method="post" enctype="multipart/form-data">
<div class="one">
<label for="name">Article Name</label>
<input type="text" name="name" id="">
</div>


<div class="one">
<label for="name">Author Name</label>
<input type="text" name="aname" id="">
</div>


<div class="one">
<label for="name">Author Designation</label>
<input type="text" name="designation" id="">
</div>



<div class="one">
<label for="name">DOI</label>
<input type="text" name="doi" id="doi">
</div>

<div class="one">
<label for="name">Page No</label>
<input type="text" name="page" id="page">
</div>

<div class="one">
<label for="name">File</label>
<input type="file" name="file" id="">
</div>



<div class="one">

<input type="submit" name="home-article-submit" value="Save" id="">
</div>
</form>

</div>



<div class="volume-list">

<?php    

include_once('../database/dbcon.php');


$sql = "SELECT * FROM `home-article` ORDER by id DESC";
$qry = mysqli_query($con,$sql);

while($row = mysqli_fetch_assoc($qry)){

?>

<div class="whole-list">

<div class="list-v">
 <?php echo $row['name'] ; ?> 
 </div>

 <a href="update-home-article.php?id=<?php echo $row['id'];  ?>">
<div class="list-link">
Edit 
</div>
</a>
</div>
<br>




<?php


}



?>






</div>














</body>
</html>