
<?php

session_start();
if(!isset($_SESSION['uid']))
{
	header('location:login/index.php');
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Journals</title>
    <link rel="stylesheet" href="admin.css">
    <?php include_once('partial/dash-link.html');  ?>

    <style>
    .list-v{
        width: auto;
    height: 50px;
    border: 1px solid;
    margin: 10px;
    display: flex;
    /* justify-content: center; */
    align-items: center;
    background-color: burlywood;
    color: black;
    padding: 5px;
    border-radius: 3px;
    }

    .list-v:hover{
        background-color: red;
    }

    .volume-list{
        display: flex;
    justify-content: center;
    flex-direction: column;
    align-content: center;
    flex-wrap: wrap;
    }
    </style>
</head>
<body>

<?php include_once('partial/dash-sidebar.html');  ?>
<?php  
include_once('../database/dbcon.php');


$sql = "SELECT * FROM journals";
$qry = mysqli_query($con,$sql);

?>

<div class="container-form">
    <h1>Add Volume</h1>

<form action="add-data.php" method="post" enctype="multipart/form-data">
<div class="one">
<label for="name">Volume Name</label>
<input type="text" name="name" id="">
</div>

<div class="one">
<label for="language">For journal</label>
<select name="journal" id="">
<?php
while($row = mysqli_fetch_assoc($qry)){
    ?>
    <option value="<?php echo $row["j_id"];  ?>"><?php echo $row["j_name"];   ?></option>
<?php
}
?>
</select>
</div>

<div class="one">

<input type="submit" name="submit-volume" value="Save" id="">
</div>
</form>

</div>

<center><h1>All Volume</h1></center>
<div class="volume-list">

<?php    

include_once('../database/dbcon.php');

$sql = "SELECT * FROM volume INNER JOIN journals WHERE volume.j_id= journals.j_id";
$qry = mysqli_query($con,$sql);

while($row = mysqli_fetch_assoc($qry)){

?>


   <a href="add-issues.php?id=<?php echo $row['id']; ?>">
   <div class="list-v">
     <b> <?php echo $row['name'] ; ?> </b> 
      
      (<?php echo $row['j_name']; ?>)  
  </div>
</a>

<?php
}



?>






</div>












<?php include_once('partial/dash-bottom.html'); ?>


</body>
</html>