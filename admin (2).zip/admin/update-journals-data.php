

<?php
include_once('../database/dbcon.php');
if(isset($_POST['submit'])){

    $id = $_POST["id"];
    $jname = $_POST["jname"];
    $abbr = $_POST["abbr"];
    $issn = $_POST["issn"];
    $frequency = $_POST["frequency"];
    $language = $_POST["language"];
    $chief = $_POST["chief"];
    $publisher = $_POST["publisher"];
    $country = $_POST["country"];
    $aim = $_POST["aim"];

    $sql = "UPDATE `journals` SET `j_name`='$jname',`abbr_title`='$abbr',`issn`='$issn',`frequency`='$frequency',`language`='$language',`chief_editor`='$chief',`publisher`='$publisher',`country_of_origin`='$country',`aim_and_scope`='$aim' WHERE `j_id`= '$id' ";

    $run = mysqli_query($con,$sql);

    if($run == true){
        ?>
        <script>
            alert('Updated');
            window.location.href='all-journals.php';
        </script>
        <?php
    }
    else{
        echo "error";

    }

}


// for image 


if(isset($_POST['img-change'])){
    $id = $_POST['id'];


    $photo = $_FILES["photo"]["name"];
    $tempname = $_FILES['photo']['tmp_name'];

    move_uploaded_file($tempname,"../assets/journals/$photo");

    $sql = "UPDATE `journals` SET `photo`= '$photo' WHERE `j_id`= '$id'";

    $run = mysqli_query($con,$sql);

    if($run == true){
        ?>
        <script>
            alert('Updated');
            window.location.href='all-journals.php';
        </script>
        <?php
    }
    else{
        echo "error";

    }

    

   

}





?>

