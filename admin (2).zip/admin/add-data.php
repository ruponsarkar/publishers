
<?php

session_start();
if(!isset($_SESSION['uid']))
{
	header('location:login/index.php');
}


?>



<?php
include_once('../database/dbcon.php');

if(isset($_POST["submit-journals"])){

    $jname = $_POST["jname"];
    $abbr = $_POST["abbr"];
    $issn = $_POST["issn"];
    $frequency = $_POST["frequency"];
    $language = $_POST["language"];
    $chief = $_POST["chief"];
    $publisher = $_POST["publisher"];
    $country = $_POST["country"];
    $aim = $_POST["aim"];
    $photo = $_FILES["photo"]["name"];
    $tempname = $_FILES['photo']['tmp_name'];

    move_uploaded_file($tempname,"../assets/journals/$photo");


    $qry = "INSERT INTO `journals`(`j_name`, `abbr_title`, `issn`, `frequency`, `language`, `chief_editor`, `publisher`, `country_of_origin`, `aim_and_scope`, `photo`) VALUES ('$jname','$abbr','$issn','$frequency','$language','$chief','$publisher','$country','$aim','$photo')";

    $run=mysqli_query($con,$qry);
    
    if($run == true)
    {
      ?>
      <script>
        alert('Successfully submitted ');
        window.location.href="add-journal.php ";
        
        
      </script>
      <?php
    }
    else echo "error";






    


}


if(isset($_POST["submit-editors"])){



    $name = $_POST["name"];
    $university = $_POST["university"];
    $details = $_POST["details"];
    $type = $_POST["type"];
    $journal = $_POST["journal"];

    $photo = $_FILES["photo"]["name"];
    $tempname = $_FILES['photo']['tmp_name'];

    move_uploaded_file($tempname,"../assets/all-editors/$photo");

    $qry = "INSERT INTO `editors_data`(`name`, `university`, `details`, `image`, `type`, `j_id`) VALUES ('$name','$university','$details','$photo','$type','$journal') ";




    $run=mysqli_query($con,$qry);
    
    if($run == true)
    {
      ?>
      <script>
        alert('Successfully submitted ');
        window.location.href="add-editors.php ";
        
        
      </script>
      <?php
    }
    else echo "error";

}










if(isset($_POST["submit-slider-editors"])){



    $name = $_POST["name"];
    $university = $_POST["university"];
    $details = $_POST["details"];

    $photo = $_FILES["photo"]["name"];
    $tempname = $_FILES['photo']['tmp_name'];

    move_uploaded_file($tempname,"../assets/all-editors/slider/$photo");

    $qry = "INSERT INTO `slide_editors`(`name`, `university`, `details`, `image`) VALUES ('$name','$university','$details','$photo') ";




    $run=mysqli_query($con,$qry);
    
    if($run == true)
    {
      ?>
      <script>
        alert('Successfully submitted ');
        window.location.href="slider-editors.php ";
        
        
      </script>
      <?php
    }
    else echo "error";

}







if(isset($_POST["submit-volume"])){


 
  $name = $_POST["name"];
  $id = $_POST["journal"];


  $qry = "INSERT INTO `volume`(`name`, `j_id`) VALUES ('$name', '$id')";




  $run=mysqli_query($con,$qry);
  
  if($run == true)
  {
    ?>
    <script>
      alert('Successfully submitted ');
      window.location.href="add-volume.php?id=<?php echo $id; ?> ";
      
      
    </script>
    <?php
  }
  else echo "error";

}









if(isset($_POST["submit-issues"])){


  $id = $_GET['id'];

  $name = $_POST["name"];


$qry = "INSERT INTO `issues`(`name`, `v_id`) VALUES ('$name', '$id')";




$run=mysqli_query($con,$qry);

if($run == true)
{
  ?>
  <script>
    alert('Successfully submitted ');
    window.location.href="add-issues.php?id=<?php echo $id;  ?> ";
    
    
  </script>
  <?php
}
else echo "error";
 

}






if(isset($_POST["submit-article"])){


  $i_id = $_GET['id'];
  $v_id = $_GET['v_id'];

  $name = $_POST["name"];
  $aname = $_POST["aname"];
  $designation = $_POST["designation"];
  $doi = $_POST["doi"];


  $file = $_FILES["file"]["name"];
  
  $tempname = $_FILES['file']['tmp_name'];

  move_uploaded_file($tempname,"../assets/finalsubmit/$file");




$qry = "INSERT INTO `article`(`name`, `aname`,`designation`, `dio`, `file`, `i_id`, `v_id`) VALUES ('$name', '$aname', '$designation', '$doi', '$file', '$i_id', '$v_id')";




$run=mysqli_query($con,$qry);

if($run == true)
{
  ?>
  <script>
    alert('Successfully submitted ');
    window.location.href="add-article.php?id=<?php echo $i_id;  ?>&v_id=<?php echo $v_id; ?> ";
    
    
  </script>
  <?php
}
else echo "error";
 

}















?>