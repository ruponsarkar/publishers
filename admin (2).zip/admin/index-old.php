
<?php

session_start();
if(!isset($_SESSION['uid']))
{
	header('location:login/index.php');
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
    <link rel="stylesheet" href="admin.css">
</head>
<body>
<a href="login/logout.php">Logout</a>


<section>

<div class="pannel">
    <div class="manuscript">
        <a class="buttom" href="all-manuscript.php">Manuscript receive</a>
        <a class="buttom" href="receive-editors.php">Editor Request receive</a>
        <a class="buttom" href="receive-reviewers.php">Reviewer Request receive</a>
        <a class="buttom" href="get-in-touch-data.php">Get in Touch Check</a>
        <hr/>
        <a class="buttom" href="add-journal.php">Add Journals</a>
        <a class="buttom" style="background: green;" href="all-journals.php">Update Journals</a>

        <br>
        <a class="buttom" href="add-editors.php">Add Editors</a>
        
        <a class="buttom" style="background: green;" href="all-editors.php">Update Editors</a>
        <br>
        <a class="buttom" href="slider-editors.php">Slider Editors</a>
        <a class="buttom" style="background: green;" href="all-slider-editors.php">Update Slider Editors</a>
        <br>



        <a class="buttom" href="add-volume.php">Volume</a>
        

    </div>
</div>










</section>














<!-- <iframe src="../assets/manuscript/1.pdf" width='1366px' height='1023px' frameborder="0">Ad</iframe> -->


    
</body>
</html>