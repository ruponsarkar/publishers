
<?php

session_start();
if(!isset($_SESSION['uid']))
{
	header('location:login/index.php');
}


?>


<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">

        <title>Dashboard</title>

<?php include_once('partial/dash-link.html');  ?>


    </head>
    <body>



        <div class="wrapper">
            <div class="card">
            <!-- Sidebar Holder -->


            <?php include_once('partial/dash-sidebar.html');  ?>













                







<?php include_once('partial/dash-bottom.html');   ?>

    </body>
</html>
