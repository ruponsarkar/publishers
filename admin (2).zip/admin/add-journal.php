
<?php

session_start();
if(!isset($_SESSION['uid']))
{
	header('location:login/index.php');
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Journals</title>
    <link rel="stylesheet" href="admin.css">
    
   <?php include_once('partial/dash-link.html');  ?>
</head>
<body>
<?php include_once('partial/dash-sidebar.html');  ?>

<div class="container-form">
    <h1>Add Journals</h1>

<form action="add-data.php" method="post" enctype="multipart/form-data">
<div class="one">
<label for="jname">Journal Name</label>
<input type="text" name="jname" id="">
</div>

<div class="one">
<label for="abbr">Abbr. Title</label>
<input type="text" name="abbr" id="">
</div>

<div class="one">
<label for="issn">ISSN</label>
<input type="text" name="issn" id="">
</div>

<div class="one">
<label for="frequency">Frequency</label>
<input type="text" name="frequency" id="">
</div>

<div class="one">
<label for="language">Language</label>
<input type="text" name="language" id="">
</div>

<div class="one">
<label for="chief">Chief Editor</label>
<input type="text" name="chief" id="">
</div>

<div class="one">
<label for="publisher">Publisher</label>
<input type="text" name="publisher" id="">
</div>

<div class="one">
<label for="country">Country Of Origin</label>
<input type="text" name="country" id="">
</div>

<div class="one" style="height: auto;">
<label for="aim">Aim And Scope</label>
<textarea id="" name="aim" placeholder="Aim and scope.." style="height:100px"></textarea>
</div>

<div class="one">
<label for="photo">Cover Photo</label>
<input type="file" name="photo" id="">
</div>

<div class="one">

<input type="submit" name="submit-journals" value="Save" id="">
</div>
</form>

</div>
<?php include_once('partial/dash-bottom.html'); ?>
</body>
</html>